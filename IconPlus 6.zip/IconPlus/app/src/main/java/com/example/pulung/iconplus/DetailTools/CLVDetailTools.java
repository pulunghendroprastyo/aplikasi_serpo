package com.example.pulung.iconplus.DetailTools;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.pulung.iconplus.R;

/**
 * Created by pulung on 11/29/17.
 */

public class CLVDetailTools extends ArrayAdapter<String> {
    //Declarasi
    private final Activity context;
    private final String[] vMerk;
    private final String[] vSN;



    public CLVDetailTools(Activity context, String[] Merk, String[] SN) {
        super(context, R.layout.list_detail_tools,Merk);
        this.context    = context;
        this.vMerk      = Merk;
        this.vSN        = SN;



    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        //Load Custom Layout untuk list
        View rowView= inflater.inflate(R.layout.list_detail_tools, null, true);
        //Declarasi komponen
        RelativeLayout reasonCard = (RelativeLayout) rowView.findViewById(R.id.listLayout);

        //Declarasi komponen
        TextView merkTxt = (TextView) rowView.findViewById(R.id.txtMerk);
        TextView snTxt = (TextView) rowView.findViewById(R.id.txtSN);

        //Set Parameter Value
        merkTxt.setText("Merk: "+vMerk[position]);
        snTxt.setText("SN: "+vSN[position]);

        return rowView;
    }


}