package com.example.pulung.iconplus.TSarpen;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.example.pulung.iconplus.R;
import com.example.pulung.iconplus.fungsi;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ListTransaksiSarpen extends AppCompatActivity {

    ListView listProses;
    String[][] rJson;
    String[] rNamaSarpen,rMerk,rNopol,rAlamat,rGambarSarpen,rKetTransaksi,rTanggal;
    ProgressBar waitList;
    String profUsername,profIdSerpo;
    SharedPreferences sharePref;
    String URLlvm;


    TextView noData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_transaksi_sarpen);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        listProses = (ListView) findViewById(R.id.listViewProses);
        waitList =(ProgressBar)findViewById(R.id.progressBar1);

        noData = (TextView) findViewById(R.id.txtNoData) ;

        //SESSION
        sharePref       = getSharedPreferences("profShare", Context.MODE_PRIVATE);
        profUsername    = sharePref.getString("profUsername","");
        profIdSerpo     = sharePref.getString("profIdSerpo","");

        URLlvm = getString(R.string.main_web)+"data_transaksi_sarpen.php?id_serpo="+profIdSerpo;
        URLlvm = URLlvm.replace(" ","%20");
        //Toast.makeText(getApplicationContext(), URLlvm, Toast.LENGTH_SHORT).show();
        new listViewProses().execute();
    }


    private class listViewProses extends AsyncTask<Void,Void,String> {

        String resultLVM;
        protected void onPreExecute() {
            super.onPreExecute();
            waitList.setVisibility(View.VISIBLE);
            noData.setVisibility(View.INVISIBLE);
        }

        @Override
        protected String doInBackground(Void... params) {

            resultLVM = new fungsi().getString(ListTransaksiSarpen.this, URLlvm);

            try {

                JSONObject jsObjek2 = new JSONObject(resultLVM);

                String dataAksi = jsObjek2.getString("aksi");

                if (dataAksi!=null){

                    JSONArray jArrayTanam = new JSONArray(dataAksi);

                    rJson = new String[jArrayTanam.length()][7];

                    for (int i = 0; i < jArrayTanam.length(); i++) {
                        JSONObject json_data5 = jArrayTanam.getJSONObject(i);


                        rJson[i][0] = json_data5.getString("nama_sarpen");
                        rJson[i][1] = json_data5.getString("merk");
                        rJson[i][2] = json_data5.getString("nopol");
                        rJson[i][3] = json_data5.getString("alamat");
                        rJson[i][4] = json_data5.getString("ket_transaksi");
                        rJson[i][5] = json_data5.getString("gambar_sarpen");
                        rJson[i][6] = json_data5.getString("tanggal");

                    }

                    rNamaSarpen     = new String[rJson.length];
                    rMerk           = new String[rJson.length];
                    rNopol          = new String[rJson.length];
                    rAlamat         = new String[rJson.length];
                    rKetTransaksi   = new String[rJson.length];
                    rGambarSarpen   = new String[rJson.length];
                    rTanggal        = new String[rJson.length];

                    for (int x = 0; x < rJson.length; x++) {

                        rNamaSarpen[x]      = rJson[x][0];
                        rMerk[x]            = rJson[x][1];
                        rNopol[x]           = rJson[x][2];
                        rAlamat[x]          = rJson[x][3];
                        rKetTransaksi[x]    = rJson[x][4];
                        rGambarSarpen[x]    = rJson[x][5];
                        rTanggal[x]         = rJson[x][6];

                    }
                }
            } catch (JSONException e) {
                Log.e("log_tag", "Error parsing data " + e.toString());
                e.printStackTrace();
                cancel(true);
            }

            return null;
        }

        @Override
        protected void onCancelled(String s) {
            super.onCancelled(s);
            listProses.setAdapter(null);

            //Toast.makeText(HomeActivity.this.HomeActivity.this, "No Data", Toast.LENGTH_SHORT).show();
            waitList.setVisibility(View.INVISIBLE);
            noData.setVisibility(View.VISIBLE);

        }

        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            waitList.setVisibility(View.INVISIBLE);
            noData.setVisibility(View.INVISIBLE);
            //Toast.makeText(HomeActivity.this.HomeActivity.this, resultLVM, Toast.LENGTH_SHORT).show();

            final CLVTSarpen adapter = new CLVTSarpen(ListTransaksiSarpen.this,rNamaSarpen,rMerk,rNopol,rAlamat,rKetTransaksi,rTanggal,rGambarSarpen);
            //get Id List

            //Set adapter to list
            listProses.setAdapter(adapter);
            //Set ketika salah satu list di pilih(klik)
            listProses.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {



                }
            });

        }
    }
}
