package com.example.pulung.iconplus;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.pulung.iconplus.Aksesoris.InputAksesoris;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Login extends Activity{

    EditText UsernameTxt, passwordTxt;
    Button loginBtn, registerBtn;

    Intent fromLogin;
    String username, passwordIn;
    // Spinner spinAir;
    String loginResult, URLlogin,URLKirimLog;

    String[] rAir;
    String Token;

    String[][] rAksi;
    String profIdLogin,profUsername,profNamaSerpo,profIdSerpo;

    SharedPreferences sharePref;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        UsernameTxt = (EditText) findViewById(R.id.mobileTxt);
        loginBtn = (Button) findViewById(R.id.loginBtn);
        // spinAir = (Spinner) findViewById(R.id.spinAir);
        passwordTxt = (EditText) findViewById(R.id.passwordTxt);

        // Toast.makeText(loginMaskapai.this, "Role : " + role, Toast.LENGTH_SHORT).show();
        sharePref = getSharedPreferences("profShare", Context.MODE_PRIVATE);


        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                username = UsernameTxt.getText().toString();
                passwordIn = passwordTxt.getText().toString();


                if (username.equals("") || passwordIn.equals("")){
                    Toast.makeText(Login.this, "Username and password cannot be empty.", Toast.LENGTH_SHORT).show();

                }
                else {

                    URLlogin = getString(R.string.main_web)+"cek_login.php?password="+passwordIn+"&username="+username;
                    URLlogin = URLlogin.replace(" ","%20");

                    URLKirimLog =getString(R.string.main_web)+"log_login.php";

                    //Toast.makeText(loginMaskapai.this, URLlogin, Toast.LENGTH_SHORT).show();
                    //Toast.makeText(loginMaskapai.this, "result : " +, Toast.LENGTH_SHORT).show();

                    new loginProgress().execute();

                }


            }
        });
    }



    @Override
    protected void onResume() {
        sharePref = getSharedPreferences("profShare", Context.MODE_PRIVATE);
        if (sharePref.contains("profIdLogin"))
        {
            // if(sharePref.contains(userPass)){
            Intent i = new Intent(getApplicationContext(), MainActivity.class);
                /*i.putExtra("profId",sharePref.getString("profId",""));
                i.putExtra("profName",sharePref.getString("profName",""));
                i.putExtra("profHp",sharePref.getString("profHp",""));
                i.putExtra("profMaskapai",sharePref.getString("profMaskapai",""));
                i.putExtra("profImg",sharePref.getString("profImg",""));*/
            startActivity(i);
            // }
        }
        super.onResume();
    }



    private class loginProgress extends AsyncTask<Void,Void,String> {


        private ProgressDialog pd = new ProgressDialog(Login.this);
        protected void onPreExecute() {
            super.onPreExecute();
            pd.setMessage("Proses login ...");
            pd.show();
        }

        @Override
        protected String doInBackground(Void... params) {


            loginResult = new fungsi().getString(Login.this, URLlogin);


            return null;
        }

        @Override
        protected void onCancelled() {
            pd.hide();
            pd.dismiss();
            super.onCancelled();
        }

        protected void onPostExecute(String result) {
            // Toast.makeText(loginMaskapai.this, loginResult, Toast.LENGTH_SHORT).show();
            pd.hide();
            pd.dismiss();
            if (loginResult.trim().equals("Berhasil")){


                new loadProfil().execute();

            }

            else {
                Toast.makeText(Login.this, "Login Failed", Toast.LENGTH_SHORT).show();
            }


        }
    }


    private class LogLogin extends AsyncTask<Void,Void,String> {


        private ProgressDialog pd = new ProgressDialog(Login.this);
        protected void onPreExecute() {
            super.onPreExecute();
            pd.setCancelable(false);
            pd.setMessage("Loading...");
            pd.show();
        }

        @Override
        protected String doInBackground(Void... params) {


            ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
            nameValuePairs.add(new BasicNameValuePair("serpo",profNamaSerpo));
            nameValuePairs.add(new BasicNameValuePair("username",profUsername));


            new fungsi().sendData(URLKirimLog, nameValuePairs);
            return "Success";

        }
        @Override
        protected void onCancelled() {
            pd.hide();
            pd.dismiss();
            super.onCancelled();
        }

        protected void onPostExecute(String result) {

            pd.hide();
            pd.dismiss();

            SharedPreferences.Editor editor =  sharePref.edit();
            editor.putString("profIdLogin", profIdLogin);
            editor.putString("profUsername", profUsername);
            editor.putString("profNamaSerpo",profNamaSerpo);
            editor.putString("profIdSerpo",profIdSerpo);

            editor.commit();

            fromLogin = new Intent(Login.this, MainActivity.class );

            startActivity(fromLogin);

        }
    }


    private class loadProfil extends AsyncTask<Void,Void,String> {

        String profilResult, URLProfil = "http://rorit.id/icon_serpo/json/data_profil.php?username="+username;


        private ProgressDialog pd = new ProgressDialog(Login.this);
        protected void onPreExecute() {
            super.onPreExecute();
            pd.setMessage("Loading ...");
            pd.show();
        }

        @Override
        protected String doInBackground(Void... params) {

            URLProfil = URLProfil.replace(" ","%20");
            profilResult = new fungsi().getString(Login.this, URLProfil);

            try {

                JSONObject jsObjek2 = new JSONObject(profilResult);

                String dataAksi = jsObjek2.getString("profil");

                if (dataAksi!=null){

                    JSONArray jArrayTanam = new JSONArray(dataAksi);

                    rAksi = new String[jArrayTanam.length()][4];

                    for (int x = 0; x < jArrayTanam.length(); x++) {
                        JSONObject json_data = jArrayTanam.getJSONObject(x);

                        rAksi[x][0] = json_data.getString("id_login");
                        rAksi[x][1] = json_data.getString("username");
                        rAksi[x][2] = json_data.getString("id_serpo");
                        rAksi[x][3] = json_data.getString("nama_serpo");

                    }

                    profIdLogin     = rAksi[0][0];
                    profUsername    = rAksi[0][1];
                    profIdSerpo     = rAksi[0][2];
                    profNamaSerpo   = rAksi[0][3];



                }


            } catch (JSONException e) {
                Log.e("log_tag", "WEB: " + URLProfil + "Error parsing data " + e.toString());
            }

            return null;
        }

        @Override
        protected void onCancelled() {
            pd.hide();
            pd.dismiss();
            super.onCancelled();
        }

        protected void onPostExecute(String result) {

          new LogLogin().execute();

        }
    }



}
