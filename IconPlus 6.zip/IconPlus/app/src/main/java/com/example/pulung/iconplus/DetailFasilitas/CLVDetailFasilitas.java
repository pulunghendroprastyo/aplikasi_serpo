package com.example.pulung.iconplus.DetailFasilitas;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.pulung.iconplus.R;

/**
 * Created by pulung on 12/4/17.
 */

public class CLVDetailFasilitas extends ArrayAdapter<String> {
    //Declarasi
    private final Activity context;
    private final String[] vId;
    private final String[] vMerk;
    private final String[] vImei;

    public CLVDetailFasilitas(Activity context,String[] Id, String[] Merk, String[] Imei) {
        super(context, R.layout.list_detail_tools,Id);
        this.context    = context;
        this.vId        = Id;
        this.vMerk      = Merk;
        this.vImei      =Imei;

    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        //Load Custom Layout untuk list
        View rowView= inflater.inflate(R.layout.list_detail_tools, null, true);
        //Declarasi komponen
        RelativeLayout reasonCard = (RelativeLayout) rowView.findViewById(R.id.listLayout);

        //Declarasi komponen
        TextView merkTxt = (TextView) rowView.findViewById(R.id.txtMerk);
        TextView ImeiTxt = (TextView) rowView.findViewById(R.id.txtSN);

            //Set Parameter Value
            merkTxt.setText("Merk: "+vMerk[position]);
            ImeiTxt.setText("Imei: "+vImei[position]);

        return rowView;
    }


}