package com.example.pulung.iconplus.Tools;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.pulung.iconplus.DataTools.CLVDataTools;
import com.example.pulung.iconplus.DataTools.DataTools;
import com.example.pulung.iconplus.DetailTools.DetailTools;
import com.example.pulung.iconplus.R;
import com.example.pulung.iconplus.SDM.CLVSDM;
import com.example.pulung.iconplus.SDM.InputSDM;
import com.example.pulung.iconplus.SDM.KurangSDM;
import com.example.pulung.iconplus.SDM.ListSDM;
import com.example.pulung.iconplus.fungsi;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ListTools extends AppCompatActivity {
    ListView listProses;
    String[][] rJson;
    String[] rIdTools,rNamaTools,rJumlah;
    ProgressBar waitList;
    SharedPreferences sharePref;
    String URLlvm,profIdSerpo,aksi;


    TextView noData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_tools);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        listProses = (ListView) findViewById(R.id.listViewProses);
        waitList =(ProgressBar)findViewById(R.id.progressBar1);

        noData = (TextView) findViewById(R.id.txtNoData) ;

        aksi = getIntent().getStringExtra("aksi");

        //SESSION
        sharePref       = getSharedPreferences("profShare", Context.MODE_PRIVATE);
        profIdSerpo   = sharePref.getString("profIdSerpo","");


        if (aksi.trim().equals("Tambah"))
        {
            URLlvm = getString(R.string.main_web)+"data_tools.php";
            URLlvm = URLlvm.replace(" ","%20");
            new listViewProses().execute();

        }
        else {
            URLlvm = getString(R.string.main_web)+"list_data_tools.php?id_serpo="+profIdSerpo;
            URLlvm = URLlvm.replace(" ","%20");
            new listViewKurang().execute();

        }
    }

    private class listViewProses extends AsyncTask<Void,Void,String> {

        String resultLVM;
        protected void onPreExecute() {
            super.onPreExecute();
            waitList.setVisibility(View.VISIBLE);
            noData.setVisibility(View.INVISIBLE);
        }

        @Override
        protected String doInBackground(Void... params) {

            resultLVM = new fungsi().getString(ListTools.this, URLlvm);

            try {

                JSONObject jsObjek2 = new JSONObject(resultLVM);

                String dataAksi = jsObjek2.getString("aksi");

                if (dataAksi!=null){

                    JSONArray jArrayTanam = new JSONArray(dataAksi);

                    rJson = new String[jArrayTanam.length()][2];

                    for (int i = 0; i < jArrayTanam.length(); i++) {
                        JSONObject json_data5 = jArrayTanam.getJSONObject(i);


                        rJson[i][0] = json_data5.getString("id_tools");
                        rJson[i][1] = json_data5.getString("nama_tools");


                    }

                    rIdTools    = new String[rJson.length];
                    rNamaTools  = new String[rJson.length];



                    for (int x = 0; x < rJson.length; x++) {

                        rIdTools[x]   = rJson[x][0];
                        rNamaTools[x] = rJson[x][1];



                    }
                }
            } catch (JSONException e) {
                Log.e("log_tag", "Error parsing data " + e.toString());
                e.printStackTrace();
                cancel(true);
            }

            return null;
        }

        @Override
        protected void onCancelled(String s) {
            super.onCancelled(s);
            listProses.setAdapter(null);

            //Toast.makeText(HomeActivity.this.HomeActivity.this, "No Data", Toast.LENGTH_SHORT).show();
            waitList.setVisibility(View.INVISIBLE);
            noData.setVisibility(View.VISIBLE);

        }

        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            waitList.setVisibility(View.INVISIBLE);
            noData.setVisibility(View.INVISIBLE);
            //Toast.makeText(HomeActivity.this.HomeActivity.this, resultLVM, Toast.LENGTH_SHORT).show();

            final CLVTools adapter = new CLVTools(ListTools.this,rIdTools,rNamaTools);
            //get Id List

            //Set adapter to list
            listProses.setAdapter(adapter);
            //Set ketika salah satu list di pilih(klik)
            listProses.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                    if (aksi.equals("Tambah"))
                    {
                        Intent a = new Intent(ListTools.this, InputTools.class);
                        a.putExtra("nama_tools",rNamaTools[position]);
                        a.putExtra("id_tools",rIdTools[position]);
                        a.putExtra("aksi",aksi);
                        startActivity(a);

                    }
                    else {
                        Intent a = new Intent(ListTools.this, KurangTools.class);
                        a.putExtra("nama_tools",rNamaTools[position]);
                        a.putExtra("id_tools",rIdTools[position]);
                        a.putExtra("aksi",aksi);
                        startActivity(a);

                    }


                }
            });

        }
    }

    private class listViewKurang extends AsyncTask<Void,Void,String> {



        String resultLVM;
        protected void onPreExecute() {
            super.onPreExecute();
            waitList.setVisibility(View.VISIBLE);
            noData.setVisibility(View.INVISIBLE);
        }

        @Override
        protected String doInBackground(Void... params) {

            resultLVM = new fungsi().getString(ListTools.this, URLlvm);

            try {

                JSONObject jsObjek2 = new JSONObject(resultLVM);

                String dataAksi = jsObjek2.getString("aksi");

                if (dataAksi!=null){

                    JSONArray jArrayTanam = new JSONArray(dataAksi);

                    rJson = new String[jArrayTanam.length()][3];

                    for (int i = 0; i < jArrayTanam.length(); i++) {
                        JSONObject json_data5 = jArrayTanam.getJSONObject(i);


                        rJson[i][0] = json_data5.getString("id_tools");
                        rJson[i][1] = json_data5.getString("nama_tools");
                        rJson[i][2] = json_data5.getString("jumlah");


                    }

                    rIdTools    = new String[rJson.length];
                    rNamaTools  = new String[rJson.length];
                    rJumlah     = new String[rJson.length];


                    for (int x = 0; x < rJson.length; x++) {

                        rIdTools[x]     = rJson[x][0];
                        rNamaTools[x]   = rJson[x][1];
                        rJumlah[x]      = rJson[x][2];

                    }
                }
            } catch (JSONException e) {
                Log.e("log_tag", "Error parsing data " + e.toString());
                e.printStackTrace();
                cancel(true);
            }

            return null;
        }

        @Override
        protected void onCancelled(String s) {
            super.onCancelled(s);
            listProses.setAdapter(null);

            //Toast.makeText(HomeActivity.this.HomeActivity.this, "No Data", Toast.LENGTH_SHORT).show();
            waitList.setVisibility(View.INVISIBLE);
            noData.setVisibility(View.VISIBLE);

        }

        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            waitList.setVisibility(View.INVISIBLE);
            noData.setVisibility(View.INVISIBLE);
            //Toast.makeText(HomeActivity.this.HomeActivity.this, resultLVM, Toast.LENGTH_SHORT).show();

            final CLVDataTools adapter = new CLVDataTools(ListTools.this,rIdTools,rNamaTools,rJumlah);
            //get Id List

            //Set adapter to list
            listProses.setAdapter(adapter);
            //Set ketika salah satu list di pilih(klik)
            listProses.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                    if (aksi.equals("Tambah"))
                    {
                        Intent a = new Intent(ListTools.this, InputTools.class);
                        a.putExtra("nama_tools",rNamaTools[position]);
                        a.putExtra("id_tools",rIdTools[position]);
                        a.putExtra("aksi",aksi);
                        startActivity(a);

                    }
                    else {
                        Intent a = new Intent(ListTools.this, KurangTools.class);
                        a.putExtra("nama_tools",rNamaTools[position]);
                        a.putExtra("id_tools",rIdTools[position]);
                        a.putExtra("aksi",aksi);
                        startActivity(a);

                    }

                }
            });

        }
    }
}
