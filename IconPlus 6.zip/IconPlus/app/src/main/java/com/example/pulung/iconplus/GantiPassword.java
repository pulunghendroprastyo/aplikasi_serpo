package com.example.pulung.iconplus;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class GantiPassword extends AppCompatActivity {

    String pass1, pass2, oldPass, password, profIdLogin, profId;
    EditText passwordTxt, konfPasswordTxt, oldPasswordTxt ;
    Button changeBtn;
    SharedPreferences sharePref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ganti_password);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        toolbar.setNavigationIcon(R.drawable.ic_back);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        passwordTxt = (EditText) findViewById(R.id.passwordTxt);
        konfPasswordTxt = (EditText) findViewById(R.id.konfPasswordTxt);
        changeBtn = (Button) findViewById(R.id.changeBtn);
        oldPasswordTxt = (EditText) findViewById(R.id.oldPasswordTxt);

        sharePref = getSharedPreferences("profShare", Context.MODE_PRIVATE);
        profIdLogin = sharePref.getString("profIdLogin","");

        //Toast.makeText(GantiPassword.this, profIdLogin, Toast.LENGTH_SHORT).show();


        changeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pass1 = passwordTxt.getText().toString();
                pass2 = konfPasswordTxt.getText().toString();
                oldPass = oldPasswordTxt.getText().toString();

                checkPass(pass1, pass2);
            }
        });
    }

    private void checkPass(String p1, String p2){



        if (p1.length()<8 || p2.length()<8 ){

            if (p1.equals("") || p2.equals("")){
                Toast.makeText(GantiPassword.this, "Mohon isi password anda", Toast.LENGTH_SHORT).show();

            }
            else {
                Toast.makeText(GantiPassword.this, "Minimal 8 karakter", Toast.LENGTH_SHORT).show();
            }

        }
        else {

            if(p1.equals(p2)){
                password = p1;
                //Toast.makeText(regPassword.this, "Registration Completed", Toast.LENGTH_SHORT).show();
                new register().execute();
            }
            else{
                Toast.makeText(GantiPassword.this, "Password anda tidak sama", Toast.LENGTH_SHORT).show();
            }

        }




    }

    public class register extends AsyncTask<Void, Void, String> {

        String URLChange = getString(R.string.main_web)+"update_password.php?id_login="+profIdLogin+"&password="+password
                +"&password_lama="+oldPass;
        String changeResult;

        private ProgressDialog pd = new ProgressDialog(GantiPassword.this);
        protected void onPreExecute() {
            super.onPreExecute();
            pd.setMessage("Mengubah Password ...");
            pd.show();
        }

        @Override
        protected String doInBackground(Void... params) {

            changeResult = new fungsi().getString(GantiPassword.this, URLChange);
            return "Success";

        }
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();
            //Toast.makeText(changePass.this, changeResult, Toast.LENGTH_SHORT).show();
            if(changeResult.trim().equals("Berhasil")){
                logout();
                Toast.makeText(GantiPassword.this, "Sukses mengubah password", Toast.LENGTH_SHORT).show();
            }
            else{

                Toast.makeText(GantiPassword.this, "Password anda tidak sama", Toast.LENGTH_SHORT).show();
            }
        }


    }
    public void logout(){
        SharedPreferences sharedpreferences = sharePref;
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.clear();
        editor.commit();
        moveTaskToBack(true);
        Intent back = new Intent(GantiPassword.this,Splash.class);
        GantiPassword.this.finish();
        startActivity(back);

    }
}
