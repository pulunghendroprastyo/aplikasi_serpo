package com.example.pulung.iconplus.Tools;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.pulung.iconplus.Kabel.InputKabel;
import com.example.pulung.iconplus.MainActivity;
import com.example.pulung.iconplus.R;
import com.example.pulung.iconplus.fungsi;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.ArrayList;

public class InputTools extends AppCompatActivity {

    String aksi,HasilCek,URLCek,profUsername,profNamaSerpo,profIdSerpo,gambar;
    String merk,sn,keterangan,URLKirim,nama_tools,id_tools;
    TextView TXTAksi,TXTNama;
    ImageButton ivThumb;
    EditText ETMerk, ETSN, ETKeterangan;
    SharedPreferences sharePref;
    Button btnInput;

    Bitmap bitMap=null;
    String pictureImagePath;
    public final String APP_TAG = "MyCustomApp";
    public final static int CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE = 1034;
    public String photoFileName = "photo.jpg";
    File photoFile;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input_tools);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        //INTENT
        aksi        = getIntent().getStringExtra("aksi");
        nama_tools  = getIntent().getStringExtra("nama_tools");
        id_tools    = getIntent().getStringExtra("id_tools");

        //DEKLARASI

        TXTAksi             = (TextView) findViewById(R.id.txtAksi);
        TXTNama        = (TextView) findViewById(R.id.txtNama);
        final CardView CVAR = (CardView) findViewById(R.id.cardAR);

        TXTAksi.setText(aksi);
        TXTNama.setText(nama_tools);

        ETMerk          = (EditText) findViewById(R.id.ETMerk);
        ETKeterangan    = (EditText) findViewById(R.id.ETKeterangan);
        ETSN            = (EditText) findViewById(R.id.ETSN);
        ivThumb         = (ImageButton) findViewById(R.id.ivThumbnailPhoto);
        btnInput        = (Button) findViewById(R.id.btnInput);

        //SESSION
        sharePref       = getSharedPreferences("profShare", Context.MODE_PRIVATE);
        profUsername    = sharePref.getString("profUsername","");
        profNamaSerpo   = sharePref.getString("profNamaSerpo","");
        profIdSerpo     = sharePref.getString("profIdSerpo","");


        // Toast.makeText(InputAksesoris.this,"ID:"+profIdSerpo,Toast.LENGTH_LONG).show();

        URLKirim = getString(R.string.main_web)+"input_tools.php";


        btnInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                merk        = ETMerk.getText().toString();
                sn          = ETSN.getText().toString();
                keterangan  = ETKeterangan.getText().toString();
                kirimData();

                // Toast.makeText(InputAksesoris.this,"Jumlah:"+jumlah+" No. Asr:"+no_asr+" Keterangan:"+keterangan+" Username:"+profUsername+" Serpo:"+profNamaSerpo+" Gambar:"+gambar+" milik:"+milik,Toast.LENGTH_LONG).show();

            }
        });

        ivThumb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                if (bitMap != null) {

                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(InputTools.this);
                    alertDialogBuilder.setMessage("Apakah anda ingin mengambil ulang foto?");

                    alertDialogBuilder.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface arg0, int arg1) {
                            //Toast.makeText(context,"You clicked yes button",Toast.LENGTH_LONG).show();
                            ambilGambar();
                        }
                    });

                    alertDialogBuilder.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });

                    AlertDialog alertDialog = alertDialogBuilder.create();
                    alertDialog.show();

                    // ivThumb.setImageBitmap(bitMap);


                } else {

                    ambilGambar();
                }
            }
        });

    }
    public  void ambilGambar(){

        // create Intent to take a picture and return control to the calling application
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Create a File reference to access to future access
        photoFile = getPhotoFileUri(photoFileName);

        // wrap File object into a content provider
        // required for API >= 24
        // See https://guides.codepath.com/android/Sharing-Content-with-Intents#sharing-files-with-api-24-or-higher
        String authorities = getApplicationContext().getPackageName() + ".fileprovider";
        Uri fileProvider = FileProvider.getUriForFile(this, authorities, photoFile);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, fileProvider);

        // If you call startActivityForResult() using an intent that no app can handle, your app will crash.
        // So as long as the result is not null, it's safe to use the intent.
        if (intent.resolveActivity(getPackageManager()) != null) {
            // Start the image capture intent to take photo
            startActivityForResult(intent, CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE);

        }


    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {


        if (requestCode == CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                // by this point we have the camera photo on disk
                //Bitmap takenImage = BitmapFactory.decodeFile(String.valueOf(photoFile));
                // RESIZE BITMAP, see section below
                // Load the taken image into a preview
                bitMap = decodeSampledBitmapFromFile(String.valueOf(photoFile), 1000, 700);
                ivThumb.setImageBitmap(bitMap);
            } else { // Result was a failure
                Toast.makeText(this, "Picture wasn't taken!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public File getPhotoFileUri(String fileName)  {
        // Only continue if the SD Card is mounted
        if (isExternalStorageAvailable()) {
            // Get safe storage directory for photos
            // Use `getExternalFilesDir` on Context to access package-specific directories.
            // This way, we don't need to request external read/write runtime permissions.
            File mediaStorageDir = new File(
                    getExternalFilesDir(Environment.DIRECTORY_PICTURES), APP_TAG);

            // Create the storage directory if it does not exist
            if (!mediaStorageDir.exists() && !mediaStorageDir.mkdirs()){
                Log.d(APP_TAG, "failed to create directory");
            }
            File file = new File(mediaStorageDir.getPath() + File.separator + fileName);

            return file;

        }
        return null;
    }
    public static Bitmap decodeSampledBitmapFromFile(String path, int reqWidth, int reqHeight)
    { // BEST QUALITY MATCH

        //First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, options);

        // Calculate inSampleSize, Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        options.inPreferredConfig = Bitmap.Config.RGB_565;
        int inSampleSize = 1;

        if (height > reqHeight)
        {
            inSampleSize = Math.round((float)height / (float)reqHeight);
        }
        int expectedWidth = width / inSampleSize;

        if (expectedWidth > reqWidth)
        {
            //if(Math.round((float)width / (float)reqWidth) > inSampleSize) // If bigger SampSize..
            inSampleSize = Math.round((float)width / (float)reqWidth);
        }

        options.inSampleSize = inSampleSize;

        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;

        return BitmapFactory.decodeFile(path, options);
    }

    // Returns true if external storage for photos is available
    private boolean isExternalStorageAvailable() {
        String state = Environment.getExternalStorageState();
        return state.equals(Environment.MEDIA_MOUNTED);
    }
    private void upload(Bitmap a) {
        // Image location URL

        ByteArrayOutputStream bao = new ByteArrayOutputStream();
        a.compress(Bitmap.CompressFormat.JPEG, 50 , bao);
        byte[] ba = bao.toByteArray();
        //ba1 = Base64.encode(ba);
        int flag = 0; // you can pass the default 0 = Base64.DEFAULT
        gambar = Base64.encodeToString(ba, flag);

        Log.e("base64", "-----" + gambar);

        // Upload image to server
        new uploadToServer().execute();
    }
    public class uploadToServer extends AsyncTask<Void, Void, String> {


        private ProgressDialog pd = new ProgressDialog(InputTools.this);
        protected void onPreExecute() {
            super.onPreExecute();
            pd.setCancelable(false);
            pd.setMessage("Menginput Data Tools ...");
            pd.show();
        }

        @Override
        protected String doInBackground(Void... params) {


            ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(10);
            nameValuePairs.add(new BasicNameValuePair("nama_serpo",profNamaSerpo));
            nameValuePairs.add(new BasicNameValuePair("id_tools",id_tools));
            nameValuePairs.add(new BasicNameValuePair("sn",sn));
            nameValuePairs.add(new BasicNameValuePair("keterangan",keterangan));
            nameValuePairs.add(new BasicNameValuePair("merk",merk));
            nameValuePairs.add(new BasicNameValuePair("gambar_tools",gambar));
            nameValuePairs.add(new BasicNameValuePair("username",profUsername));
            nameValuePairs.add(new BasicNameValuePair("ket_transaksi",aksi));
            nameValuePairs.add(new BasicNameValuePair("namagambar",profUsername));
            nameValuePairs.add(new BasicNameValuePair("id_serpo",profIdSerpo));

            new fungsi().sendData(URLKirim, nameValuePairs);
            return "Success";

        }
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();
            Toast.makeText(getApplicationContext(), "Transaksi tools berhasil", Toast.LENGTH_SHORT).show();

            Intent kembali = new Intent(getApplicationContext(),MainActivity.class);

            startActivity(kembali);
        }


    }
    private void kirimData() {

        if (bitMap == null) {
            Toast.makeText(getApplicationContext(), "Tidak dapat mengirim data.\nTidak ada foto aksesoris",
                    Toast.LENGTH_SHORT).show();

        } else if (merk.equals("")) {
            Toast.makeText(getApplicationContext(), "Merk belum diisi",
                    Toast.LENGTH_SHORT).show();
        } else if (sn.equals("")) {
            Toast.makeText(getApplicationContext(), "SN belum diisi",
                    Toast.LENGTH_SHORT).show();
        } else if (ETKeterangan.getText().toString().equals("")) {
            Toast.makeText(getApplicationContext(), "Keterangan belum diisi",
                    Toast.LENGTH_SHORT).show();
        } else {

            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(InputTools.this);
            alertDialogBuilder.setMessage("Apakah semua data sudah benar ?");

            alertDialogBuilder.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface arg0, int arg1) {

                    URLCek = getString(R.string.main_web)+"cek_sn_tools.php?&merk="+merk+"&id_tools="+id_tools+"&sn="+sn;
                    URLCek = URLCek.replace(" ","%20");
                    //Toast.makeText(InputTools.this, URLCek, Toast.LENGTH_SHORT).show();
                    new CekSN().execute();
                }
            });

            alertDialogBuilder.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });

            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();

        }

    }
    public class CekSN extends AsyncTask<Void, Void, String> {


        private ProgressDialog pd = new ProgressDialog(InputTools.this);

        protected void onPreExecute() {
            super.onPreExecute();
            pd.setMessage("Cek SN ...");
            pd.show();
        }

        @Override
        protected String doInBackground(Void... params) {


            HasilCek = new fungsi().getString(InputTools.this, URLCek);


            return null;
        }

        @Override
        protected void onCancelled() {
            pd.hide();
            pd.dismiss();
            super.onCancelled();
        }

        protected void onPostExecute(String result) {
            // Toast.makeText(loginMaskapai.this, loginResult, Toast.LENGTH_SHORT).show();
            pd.hide();
            pd.dismiss();
            if (HasilCek.trim().equals("Tidak")) {

                upload(bitMap);

            } else {
                Toast.makeText(InputTools.this, "SN sudah ada", Toast.LENGTH_SHORT).show();
                //Toast.makeText(InputTools.this, HasilCek, Toast.LENGTH_SHORT).show();
            }


        }
    }

}
