package com.example.pulung.iconplus.TKabel;

/**
 * Created by pulung on 11/15/17.
 */

import android.app.Activity;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.pulung.iconplus.R;
import com.squareup.picasso.Picasso;
public class CLVTKabel extends ArrayAdapter<String> {
    //Declarasi
    private final Activity context;
    private final String[] vNama;
    private final String[] vId;
    private final String[] vJumlah;
    private final String[] vKetTransaksi;
    private final String[] vTanggal;
    private final String[] vNamaSerpo;
    private final String[] vNoASR;
    private final String[] vKeterangan;
    private final String[] vGambar;


    public CLVTKabel(Activity context, String[] Nama, String[] Id, String[] Jumlah, String[] KetTransaksi, String[] Tanggal, String[] NamaSerpo, String[] NoASR, String[] Keterangan, String[] Gambar) {
        super(context, R.layout.list_transaksi, Nama);

        this.context = context;
        this.vNama = Nama;
        this.vId = Id;
        this.vJumlah = Jumlah;
        this.vKetTransaksi = KetTransaksi;
        this.vTanggal = Tanggal;
        this.vNamaSerpo = NamaSerpo;
        this.vNoASR = NoASR;
        this.vKeterangan = Keterangan;
        this.vGambar = Gambar;


    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        //Load Custom Layout untuk list
        View rowView = inflater.inflate(R.layout.list_transaksi, null, true);
        //Declarasi komponen
        RelativeLayout reasonCard = (RelativeLayout) rowView.findViewById(R.id.listLayout);

        //Declarasi komponen
        TextView titleTxt = (TextView) rowView.findViewById(R.id.titleTxt);
        TextView jumlahTxt = (TextView) rowView.findViewById(R.id.JumlahTxt);
        TextView timeTxt = (TextView) rowView.findViewById(R.id.timeTxt);
        ImageView IVGambar = (ImageView) rowView.findViewById(R.id.IVGambar);


        //Set Parameter Value
        titleTxt.setText(vNama[position]);
        timeTxt.setText(vTanggal[position]);
        if (vKetTransaksi[position].equals("Tambah")) {
            jumlahTxt.setText("Penambahan:" + vJumlah[position] + " Meter");

        } else {
            jumlahTxt.setText("Pengurangan:" + vJumlah[position] + " Meter");
            reasonCard.setBackgroundColor(Color.parseColor("#FF9D9D"));
        }

        Picasso.with(this.context).load("http://rorit.id/icon_serpo/upload/" + vGambar[position]).into(IVGambar);

        return rowView;
    }

    public String getId(int position) {
        return vId[position];
    }

    public String getNama(int position) {
        return vNama[position];
    }

    public String getJumlah(int position) {
        return vJumlah[position];
    }

    public String getKet(int position) {
        return vKetTransaksi[position];
    }

    public String getTanggal(int position) {
        return vTanggal[position];
    }

    public String getNamaSerpo(int position) {
        return vNamaSerpo[position];
    }


    public String getNoASR(int position) {
        return vNoASR[position];
    }

    public String getKeterangan(int position) {
        return vKeterangan[position];
    }
}