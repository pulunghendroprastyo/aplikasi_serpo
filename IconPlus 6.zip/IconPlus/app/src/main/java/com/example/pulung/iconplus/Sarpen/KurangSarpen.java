package com.example.pulung.iconplus.Sarpen;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.pulung.iconplus.MainActivity;
import com.example.pulung.iconplus.R;
import com.example.pulung.iconplus.SDM.KurangSDM;
import com.example.pulung.iconplus.fungsi;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class KurangSarpen extends AppCompatActivity {

    String aksi,profUsername,profNamaSerpo,profIdSerpo,merk,GetMerk="",GetNopol="",GetAlamat="",nopol;
    String keterangan,URLKirim,URLAlamat,nama_sarpen,id_sarpen,id_sars,alamat,id_sarsalamat;
    TextView TXTAksi,TXTNama;
    EditText ETKeterangan;
    SharedPreferences sharePref;
    Button btnInput;

    ArrayList<String> NamaMerkList;
    ArrayList<String> NamaNopolList;
    ArrayList<String> NamaAlamatList;
    HashMap<Integer,String> spinnerMap;
    HashMap<Integer,String> spinnerMapAlamat;

    String URLMerk,URLNopol,dataMerk,dataAlamat,dataNopol;

    Spinner SpinnerMerk,SpinnerNopol,SpinnerAlamat;
    String GetId;

    private static final String Json_data   ="aksi";
    private static final String Json_Merk   ="merk",
                                Json_IdSars ="id_sars",
                                Json_IdSarsN ="id_sars",
                                Json_Alamat ="alamat",
                                Json_Nopol  ="nopol";

    // Data Array JSONArray
    JSONArray DatafromJsonMerk      = null;
    JSONArray DatafromJsonAlamat    = null;
    JSONArray DatafromJsonNopol     = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kurang_sarpen);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        //INTENT
        aksi         = getIntent().getStringExtra("aksi");
        nama_sarpen  = getIntent().getStringExtra("nama_sarpen");
        id_sarpen    = getIntent().getStringExtra("id_sarpen");

        //DEKLARASI
        TXTAksi             = (TextView) findViewById(R.id.txtAksi);
        TXTNama             = (TextView) findViewById(R.id.txtNama);

        final CardView CVAlamat     = (CardView) findViewById(R.id.CVAlamat);
        final CardView CVMerk       = (CardView) findViewById(R.id.CVMerk);
        final CardView CVNopol      = (CardView) findViewById(R.id.CVNopol);



        TXTAksi.setText(aksi);
        TXTNama.setText(nama_sarpen);

        ETKeterangan    = (EditText) findViewById(R.id.ETKeterangan);
        btnInput        = (Button) findViewById(R.id.btnInput);

        //SESSION
        sharePref       = getSharedPreferences("profShare", Context.MODE_PRIVATE);
        profUsername    = sharePref.getString("profUsername","");
        profNamaSerpo   = sharePref.getString("profNamaSerpo","");
        profIdSerpo     = sharePref.getString("profIdSerpo","");

        // Get Data Spinner json
        SpinnerMerk     =(Spinner)findViewById(R.id.SpinnerMerk);
        SpinnerNopol    =(Spinner)findViewById(R.id.SpinnerNopol);
        SpinnerAlamat   =(Spinner)findViewById(R.id.SpinnerAlamat);

        if (id_sarpen.equals("1"))
        {
            CVMerk.setVisibility(CVMerk.GONE);
            CVNopol.setVisibility(CVNopol.GONE);

            URLAlamat      = getString(R.string.main_web)+"cek_sbasecamp.php?id_serpo="+profIdSerpo+"&id_sarpen="+id_sarpen;
            URLAlamat      = URLAlamat.replace(" ","%20");
            new JSONSpinnerAlamat().execute();


        }
        else
        {
            CVAlamat.setVisibility(CVAlamat.GONE);

            URLMerk      = getString(R.string.main_web)+"cek_smobil.php?id_serpo="+profIdSerpo+"&id_sarpen="+id_sarpen;
            URLMerk      = URLMerk.replace(" ","%20");
            new JSONSpinnerMerk().execute();

        }



        // Toast.makeText(InputAksesoris.this,"ID:"+profIdSerpo,Toast.LENGTH_LONG).show();

        URLKirim = getString(R.string.main_web)+"input_sarpen.php";

        btnInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                keterangan  = ETKeterangan.getText().toString();
                kirimData();

                // Toast.makeText(InputAksesoris.this,"Jumlah:"+jumlah+" No. Asr:"+no_asr+" Keterangan:"+keterangan+" Username:"+profUsername+" Serpo:"+profNamaSerpo+" Gambar:"+gambar+" milik:"+milik,Toast.LENGTH_LONG).show();

            }
        });

    }
    private class JSONSpinnerAlamat extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... params) {
            // Creating service handler class instance
            NamaAlamatList = new ArrayList<String>();
            dataAlamat = new fungsi().getString(KurangSarpen.this, URLAlamat);

            Log.d("Response: ", "> " + dataAlamat);
            if (dataAlamat != null) {
                try {
                    JSONObject jsonObj = new JSONObject(dataAlamat);

                    // Getting JSON Array node
                    DatafromJsonAlamat = jsonObj.getJSONArray(Json_data);

                    spinnerMapAlamat = new HashMap<Integer, String>();

                    // looping through All Contacts
                    for (int i = 0; i < DatafromJsonAlamat.length(); i++) {
                        JSONObject c = DatafromJsonAlamat.getJSONObject(i);

                        id_sarsalamat = c.getString(Json_IdSars);
                        alamat  = c.getString(Json_Alamat);
                        spinnerMapAlamat.put(i,id_sarsalamat);
                        NamaAlamatList.add(alamat);

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                Log.e("ServiceHandler", "Couldn't get any data from the url");
            }

            return null;

        }


        @Override
        protected void onPostExecute(Void args) {
            // Locate the spinner in activity_main.xml

            ArrayAdapter<String> additionArray = new ArrayAdapter<String>(KurangSarpen.this,
                    android.R.layout.simple_spinner_item,
                    NamaAlamatList);
            additionArray.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            SpinnerAlamat.setAdapter(additionArray);
            SpinnerAlamat.setPrompt("Pilih");
            SpinnerAlamat.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                    GetAlamat = SpinnerAlamat.getSelectedItem().toString();
                    GetId     = spinnerMapAlamat.get(SpinnerAlamat.getSelectedItemPosition());



                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        }
    }
    private class JSONSpinnerMerk extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... params) {
            // Creating service handler class instance
            NamaMerkList = new ArrayList<String>();
            dataMerk = new fungsi().getString(KurangSarpen.this, URLMerk);

            Log.d("Response: ", "> " + dataMerk);
            if (dataMerk != null) {
                try {
                    JSONObject jsonObj = new JSONObject(dataMerk);

                    // Getting JSON Array node
                    DatafromJsonMerk = jsonObj.getJSONArray(Json_data);

                    // looping through All Contacts
                    for (int i = 0; i < DatafromJsonMerk.length(); i++) {
                        JSONObject c = DatafromJsonMerk.getJSONObject(i);

                        merk  = c.getString(Json_Merk);
                        NamaMerkList.add(merk);

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                Log.e("ServiceHandler", "Couldn't get any data from the url");
            }

            return null;

        }


        @Override
        protected void onPostExecute(Void args) {
            // Locate the spinner in activity_main.xml

            ArrayAdapter<String> additionArray = new ArrayAdapter<String>(KurangSarpen.this,
                    android.R.layout.simple_spinner_item,
                    NamaMerkList);
            additionArray.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            SpinnerMerk.setAdapter(additionArray);
            SpinnerMerk.setPrompt("Pilih");
            SpinnerMerk.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                    GetMerk = SpinnerMerk.getSelectedItem().toString();

                    URLNopol      = getString(R.string.main_web)+"cek_nopol.php?id_serpo="+profIdSerpo+"&id_sarpen="+id_sarpen+"&merk="+GetMerk;
                    URLNopol      = URLNopol.replace(" ","%20");
                    //Toast.makeText(getApplicationContext(), URLNopol,Toast.LENGTH_LONG).show();
                    new JSONSpinnerNopol().execute();


                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        }
    }
    private class JSONSpinnerNopol extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... params) {
            // Creating service handler class instance
            NamaNopolList = new ArrayList<String>();
            dataNopol = new fungsi().getString(KurangSarpen.this, URLNopol);

            Log.d("Response: ", "> " + dataNopol);
            if (dataNopol != null) {
                try {
                    JSONObject jsonObj = new JSONObject(dataNopol);

                    // Getting JSON Array node
                    DatafromJsonNopol = jsonObj.getJSONArray(Json_data);
                    spinnerMap = new HashMap<Integer, String>();

                    // looping through All Contacts
                    for (int i = 0; i < DatafromJsonNopol.length(); i++) {
                        JSONObject c = DatafromJsonNopol.getJSONObject(i);

                        id_sars     = c.getString(Json_IdSarsN);
                        nopol       = c.getString(Json_Nopol);

                        spinnerMap.put(i,id_sars);
                        NamaNopolList.add(nopol);

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                Log.e("ServiceHandler", "Couldn't get any data from the url");
            }

            return null;

        }


        @Override
        protected void onPostExecute(Void args) {
            // Locate the spinner in activity_main.xml

            ArrayAdapter<String> additionArray = new ArrayAdapter<String>(KurangSarpen.this,
                    android.R.layout.simple_spinner_item,
                    NamaNopolList);
            additionArray.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            SpinnerNopol.setAdapter(additionArray);
            SpinnerNopol.setPrompt("Pilih");
            SpinnerNopol.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                    GetNopol    = SpinnerNopol.getSelectedItem().toString();
                    GetId       = spinnerMap.get(SpinnerNopol.getSelectedItemPosition());

                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        }
    }

    public class uploadToServer extends AsyncTask<Void, Void, String> {


        private ProgressDialog pd = new ProgressDialog(KurangSarpen.this);
        protected void onPreExecute() {
            super.onPreExecute();
            pd.setCancelable(false);
            pd.setMessage("Mengurangi Data Sarpen ...");
            pd.show();
        }

        @Override
        protected String doInBackground(Void... params) {


            ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(9);
            nameValuePairs.add(new BasicNameValuePair("id_serpo",profIdSerpo));
            nameValuePairs.add(new BasicNameValuePair("id_sars",GetId));
            nameValuePairs.add(new BasicNameValuePair("nama_serpo",profNamaSerpo));
            nameValuePairs.add(new BasicNameValuePair("id_sarpen",id_sarpen));
            nameValuePairs.add(new BasicNameValuePair("nopol",GetNopol));
            nameValuePairs.add(new BasicNameValuePair("keterangan",keterangan));
            nameValuePairs.add(new BasicNameValuePair("merk",GetMerk));
            nameValuePairs.add(new BasicNameValuePair("username",profUsername));
            nameValuePairs.add(new BasicNameValuePair("ket_transaksi",aksi));

            new fungsi().sendData(URLKirim, nameValuePairs);
            return "Success";

        }
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();
            Toast.makeText(getApplicationContext(), "Berhasil mengurangi sarpen ", Toast.LENGTH_SHORT).show();

            Intent kembali = new Intent(getApplicationContext(),MainActivity.class);

            startActivity(kembali);
        }


    }
    private void kirimData() {
        if (id_sarpen.equals("1"))
        {
            if (GetAlamat.equals("")) {
                Toast.makeText(getApplicationContext(), "Alamat Kosong",
                        Toast.LENGTH_SHORT).show();
            }

            else if (ETKeterangan.getText().toString().equals("")) {
                Toast.makeText(getApplicationContext(), "Keterangan belum diisi",
                        Toast.LENGTH_SHORT).show();
            } else {

                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(KurangSarpen.this);
                alertDialogBuilder.setMessage("Apakah semua data sudah benar ?");

                alertDialogBuilder.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {

                        new uploadToServer().execute();

                    }
                });

                alertDialogBuilder.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();

            }

        }
        else{

            if (GetMerk.equals("")) {
                Toast.makeText(getApplicationContext(), "Merk Kosong",
                        Toast.LENGTH_SHORT).show();
            }
            else if (GetNopol.equals("")) {
                Toast.makeText(getApplicationContext(), "No. Polisi Kosong",
                        Toast.LENGTH_SHORT).show();
            }
            else if (ETKeterangan.getText().toString().equals("")) {
                Toast.makeText(getApplicationContext(), "Keterangan belum diisi",
                        Toast.LENGTH_SHORT).show();
            } else {

                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(KurangSarpen.this);
                alertDialogBuilder.setMessage("Apakah semua data sudah benar ?");

                alertDialogBuilder.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {

                        new uploadToServer().execute();

                    }
                });

                alertDialogBuilder.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();

            }


        }



    }

}