package com.example.pulung.iconplus.DetailSarpen;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.pulung.iconplus.R;

/**
 * Created by pulung on 11/30/17.
 */

public class CLVDetailSarpen extends ArrayAdapter<String> {
    //Declarasi
    private final Activity context;
    private final String[] vId;
    private final String[] vMerk;
    private final String[] vNopol;
    private final String[] vAlamat;



    public CLVDetailSarpen(Activity context,String[] Id, String[] Merk, String[] Nopol, String[] Alamat) {
        super(context, R.layout.list_detail_tools,Id);
        this.context    = context;
        this.vId        = Id;
        this.vMerk      = Merk;
        this.vNopol     = Nopol;
        this.vAlamat    = Alamat;

    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        //Load Custom Layout untuk list
        View rowView= inflater.inflate(R.layout.list_detail_tools, null, true);
        //Declarasi komponen
        RelativeLayout reasonCard = (RelativeLayout) rowView.findViewById(R.id.listLayout);

        //Declarasi komponen
        TextView merkTxt = (TextView) rowView.findViewById(R.id.txtMerk);
        TextView NopolTxt = (TextView) rowView.findViewById(R.id.txtSN);

        if (vId[position].equals("1"))
        {
            //Set Parameter Value
            merkTxt.setText("Alamat: "+vAlamat[position]);
            NopolTxt.setVisibility(NopolTxt.GONE);
        }
        else
        {
            //Set Parameter Value
            merkTxt.setText("Merk: "+vMerk[position]);
            NopolTxt.setText("No. Pol: "+vNopol[position]);

        }


        return rowView;
    }


}