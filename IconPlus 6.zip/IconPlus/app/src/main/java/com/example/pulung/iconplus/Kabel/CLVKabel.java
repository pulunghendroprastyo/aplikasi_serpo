package com.example.pulung.iconplus.Kabel;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.pulung.iconplus.R;
import com.squareup.picasso.Picasso;

/**
 * Created by pulung on 11/14/17.
 */

public class CLVKabel extends ArrayAdapter<String> {
    //Declarasi
    private final Activity context;
    private final String[] vNama;
    private final String[] vId;
    private final String[] vGambar;



    public CLVKabel(Activity context, String[] Nama, String[] Id, String[] Gambar) {
        super(context, R.layout.list_view,Nama);
        this.context = context;
        this.vNama = Nama;
        this.vId = Id;
        this.vGambar = Gambar;



    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        //Load Custom Layout untuk list
        View rowView= inflater.inflate(R.layout.list_view, null, true);
        //Declarasi komponen
        RelativeLayout reasonCard = (RelativeLayout) rowView.findViewById(R.id.listLayout);

        //Declarasi komponen
        TextView titleTxt = (TextView) rowView.findViewById(R.id.txtNama);
        ImageView IVGambar  = (ImageView) rowView.findViewById(R.id.IVGambar);


        //Set Parameter Value
        titleTxt.setText(vNama[position]);
        Picasso.with(this.context).load("http://rorit.id/icon_serpo/gambar_kabel/"+vGambar[position]).into(IVGambar);


        return rowView;
    }
    public String getId(int position){
        return vId[position];
    }
    public String getNama(int position){
        return vNama[position];
    }


}