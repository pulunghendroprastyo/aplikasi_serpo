package com.example.pulung.iconplus.TSarpen;

import android.app.Activity;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.pulung.iconplus.R;
import com.squareup.picasso.Picasso;

/**
 * Created by pulung on 11/30/17.
 */

public class CLVTSarpen extends ArrayAdapter<String> {
    //Declarasi
    private final Activity context;
    private final String[] vNama;
    private final String[] vMerek;
    private final String[] vNopol;
    private final String[] vAlamat;
    private final String[] vKetTransaksi;
    private final String[] vTanggal;
    private final String[] vGambar;

    public CLVTSarpen(Activity context, String[] Nama, String[] Merek, String[] Nopol, String[] Alamat,String[] KetTransaksi, String[] Tanggal, String[] Gambar) {
        super(context, R.layout.list_transaksi_tools, Nama);

        this.context        = context;
        this.vNama          = Nama;
        this.vMerek         = Merek;
        this.vNopol         = Nopol;
        this.vAlamat        = Alamat;
        this.vKetTransaksi  = KetTransaksi;
        this.vTanggal       = Tanggal;
        this.vGambar        = Gambar;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        //Load Custom Layout untuk list
        View rowView = inflater.inflate(R.layout.list_transaksi_tools, null, true);
        //Declarasi komponen
        RelativeLayout reasonCard = (RelativeLayout) rowView.findViewById(R.id.listLayout);

        //Declarasi komponen
        TextView titleTxt   = rowView.findViewById(R.id.titleTxt);
        TextView MerekTxt   = rowView.findViewById(R.id.MerkTxt);
        TextView NopolTxt   = rowView.findViewById(R.id.SNTxt);
        TextView timeTxt    = rowView.findViewById(R.id.timeTxt);
        ImageView IVGambar  = rowView.findViewById(R.id.IVGambar);


        //Set Parameter Value
        titleTxt.setText(vNama[position]);
        timeTxt.setText(vTanggal[position]);
        if (vNama[position].equals("Basecamp"))
        {
            if (vKetTransaksi[position].equals("Tambah")) {
                MerekTxt.setText("Alamat: "+vAlamat[position]);
                NopolTxt.setVisibility(NopolTxt.GONE);

            } else {
                MerekTxt.setText("Alamat: "+vAlamat[position]);
                NopolTxt.setVisibility(NopolTxt.GONE);
                reasonCard.setBackgroundColor(Color.parseColor("#FF9D9D"));
            }

        }
        else{

            if (vKetTransaksi[position].equals("Tambah")) {
                MerekTxt.setText("Merek: "+vMerek[position]);
                NopolTxt.setText("No. Pol: "+vNopol[position]);

            } else {
                MerekTxt.setText("Merek: "+vMerek[position]);
                NopolTxt.setText("No. Pol: "+vNopol[position]);
                reasonCard.setBackgroundColor(Color.parseColor("#FF9D9D"));
            }


        }


        Picasso.with(this.context).load("http://rorit.id/icon_serpo/upload/" + vGambar[position]).into(IVGambar);

        return rowView;
    }


    public String getNama(int position) {
        return vNama[position];
    }

    public String getKet(int position) {
        return vKetTransaksi[position];
    }

    public String getTanggal(int position) {
        return vTanggal[position];
    }

}