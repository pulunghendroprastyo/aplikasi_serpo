package com.example.pulung.iconplus;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.text.TextPaint;
import android.view.LayoutInflater;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.pulung.iconplus.DataAksesoris.DataAksesoris;
import com.example.pulung.iconplus.DataKabel.DataKabel;
import com.example.pulung.iconplus.DataPerangkat.DataPerangkat;
import com.example.pulung.iconplus.DataSDM.ListDataSDM;
import com.example.pulung.iconplus.DataSarpen.DataSarpen;
import com.example.pulung.iconplus.DataTools.DataTools;
import com.example.pulung.iconplus.Fasilitas.ListFasilitas;
import com.example.pulung.iconplus.Perangkat.ListPerangkat;
import com.example.pulung.iconplus.SDM.ListSDM;
import com.example.pulung.iconplus.Sarpen.ListSarpen;
import com.example.pulung.iconplus.TAksesoris.ListTransaksiAksesoris;
import com.example.pulung.iconplus.TKabel.ListTransaksiKabel;
import com.example.pulung.iconplus.TPerangkat.ListTransaksiPerangkat;
import com.example.pulung.iconplus.Aksesoris.ListAksesoris;
import com.example.pulung.iconplus.Kabel.ListKabel;
import com.example.pulung.iconplus.TSarpen.ListTransaksiSarpen;
import com.example.pulung.iconplus.TTools.ListTransaksiTools;
import com.example.pulung.iconplus.Tools.ListTools;
import com.github.amlcurran.showcaseview.ShowcaseView;
import com.github.amlcurran.showcaseview.targets.ActionViewTarget;
import com.github.amlcurran.showcaseview.targets.ViewTarget;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    SharedPreferences sharePref;
     TextView TXTUsername,TXTNamaSerpo;
     String profUsername,profNamaSerpo;
    String[] SMenu      = {"Sparepart", "BOQ"};
    String[] SSparepart = {"Aksesoris", "Perangkat","Kabel"};
    String[] SBOQ       = {"SDM", "Tools","Sarpen","Fasilitas"};

    String URLKirimLog;

    String menu="Sparepart",aksi,tindakan;
    RadioButton RBAksi,RBMenu;
    RadioGroup RGMenu, RGAksi;
    Button BTNNext;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        View header = LayoutInflater.from(this).inflate(R.layout.nav_header_main, null);

        URLKirimLog = getString(R.string.main_web)+"log_logout.php";

        navigationView.addHeaderView(header);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                int id = item.getItemId();

                if (id == R.id.nav_Transaksi) {

                    tindakan="Transaksi";

                    Intent a = new Intent(MainActivity.this, Data.class);
                    a.putExtra("aksi",tindakan);
                    startActivity(a);

                } else if (id == R.id.nav_Data) {
                    tindakan="Data";

                    Intent a = new Intent(MainActivity.this, Data.class);
                    a.putExtra("aksi",tindakan);
                    startActivity(a);

                }
                else
                {
                    tampilAbout();
                }


                DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
                drawer.closeDrawer(GravityCompat.START);
                //return true;
                return false;
            }
        });


        sharePref = getSharedPreferences("profShare", Context.MODE_PRIVATE);
        profUsername = sharePref.getString("profUsername","");
        profNamaSerpo = sharePref.getString("profNamaSerpo","");

        TXTUsername     = (TextView) header.findViewById(R.id.NavUsername);
        TXTNamaSerpo    = (TextView) header.findViewById(R.id.NavSerpo);

        TXTUsername.setText(profUsername);
        TXTNamaSerpo.setText(profNamaSerpo);

        //Toast.makeText(MainActivity.this, profUsername,Toast.LENGTH_LONG).show();

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();


        //SPINNER
        Spinner Menu = (Spinner) findViewById(R.id.SpinnerMenu);
        final Spinner Aksi = (Spinner) findViewById(R.id.SpinnerAksi);
        ArrayAdapter<String> additionArray = new ArrayAdapter<String>(MainActivity.this,
                android.R.layout.simple_spinner_item,
                SMenu);
        additionArray.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Menu.setAdapter(additionArray);
        Menu.setPrompt("Pilih");
        Menu.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                menu = SMenu[position];
                //Toast.makeText(MainActivity.this, menu,Toast.LENGTH_LONG).show();

                if (SMenu[position].equals("Sparepart"))
                {

                    ArrayAdapter<String> addAksi = new ArrayAdapter<String>(MainActivity.this,
                            android.R.layout.simple_spinner_item,
                            SSparepart);
                    addAksi.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    Aksi.setAdapter(addAksi);
                    Aksi.setPrompt("Pilih");
                    Aksi.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                            aksi = SSparepart[position];

                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {

                        }

                    });


                }
                else
                {
                    ArrayAdapter<String> addAksi = new ArrayAdapter<String>(MainActivity.this,
                            android.R.layout.simple_spinner_item,
                            SBOQ);
                    addAksi.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    Aksi.setAdapter(addAksi);
                    Aksi.setPrompt("Pilih");
                    Aksi.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                            aksi = SBOQ[position];

                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {

                        }

                    });


                }


            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }

        });


        RGAksi      = (RadioGroup)  findViewById(R.id.rgAksi);
        BTNNext     = (Button)      findViewById(R.id.btnNext);

        BTNNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //pilih radio button yang ada di radio button group
                int selectedIdAksi = RGAksi.getCheckedRadioButtonId();

                // mencari radio button
                RBAksi= (RadioButton) findViewById(selectedIdAksi);
                //menampilkan pesan teks / toast

                if (aksi.equals("Aksesoris"))
                {
                    Intent a = new Intent(MainActivity.this, ListAksesoris.class);
                    a.putExtra("aksi",RBAksi.getText());
                    startActivity(a);
                    Toast.makeText(getBaseContext(),
                            "Kamu Memilih  " + RBAksi.getText()+" "+aksi,
                            Toast.LENGTH_SHORT).show();

                }

                else if (aksi.equals("Kabel"))
                {
                    Intent a = new Intent(MainActivity.this, ListKabel.class);
                    a.putExtra("aksi",RBAksi.getText());
                    startActivity(a);

                    Toast.makeText(getBaseContext(),
                            "Kamu Memilih  " + RBAksi.getText()+" "+aksi,
                            Toast.LENGTH_SHORT).show();
                }
                else if (aksi.equals("Perangkat"))
                {
                    Intent a = new Intent(MainActivity.this, ListPerangkat.class);
                    a.putExtra("aksi",RBAksi.getText());
                    startActivity(a);

                    Toast.makeText(getBaseContext(),
                            "Kamu Memilih  " + RBAksi.getText()+" "+aksi,
                            Toast.LENGTH_SHORT).show();
                }
                else if (aksi.equals("SDM"))
                {
                    Intent a = new Intent(MainActivity.this, ListSDM.class);
                    a.putExtra("aksi",RBAksi.getText());
                    startActivity(a);

                    Toast.makeText(getBaseContext(),
                            "Kamu Memilih  " + RBAksi.getText()+" "+aksi,
                            Toast.LENGTH_SHORT).show();
                }
                else if (aksi.equals("Tools"))
                {
                    Intent a = new Intent(MainActivity.this, ListTools.class);
                    a.putExtra("aksi",RBAksi.getText());
                    startActivity(a);

                    Toast.makeText(getBaseContext(),
                            "Kamu Memilih  " + RBAksi.getText()+" "+aksi,
                            Toast.LENGTH_SHORT).show();
                }
                else if (aksi.equals("Sarpen"))
                {
                    Intent a = new Intent(MainActivity.this, ListSarpen.class);
                    a.putExtra("aksi",RBAksi.getText());
                    startActivity(a);

                    Toast.makeText(getBaseContext(),
                            "Kamu Memilih  " + RBAksi.getText()+" "+aksi,
                            Toast.LENGTH_SHORT).show();
                }
                else if (aksi.equals("Fasilitas"))
                {
                    Intent a = new Intent(MainActivity.this, ListFasilitas.class);
                    a.putExtra("aksi",RBAksi.getText());
                    startActivity(a);

                    Toast.makeText(getBaseContext(),
                            "Kamu Memilih  " + RBAksi.getText()+" "+aksi,
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        TextPaint paint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        paint.setTextSize(getResources().getDimension(R.dimen.abc_text_size_body_1_material));
        paint.setColor(Color.BLACK);

        TextPaint title = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        title.setTextSize(getResources().getDimension(R.dimen.abc_text_size_headline_material));
        title.setUnderlineText(true);
        title.setColor(Color.BLACK);

        new ShowcaseView.Builder(this)
                .setTarget(new ViewTarget(R.id.SpinnerAksi,this))
                .setContentTextPaint(paint)
                .setContentTitle("Selamat Datang")
                .setContentText("Ini merupakan menu utama dari aplikasi serpo. ")
                .setContentTitlePaint(title)
                .singleShot(1)
                .build();


    }

    @Override
    public void onBackPressed() {

            DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
            if (drawer.isDrawerOpen(GravityCompat.START)) {
                drawer.closeDrawer(GravityCompat.START);
            } else {
                /// super.onBackPressed();
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);
                alertDialogBuilder.setMessage("ingin keluar dari aplikasi ?");

                alertDialogBuilder.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        //Toast.makeText(context,"You clicked yes button",Toast.LENGTH_LONG).show();
                        //finish();
                        moveTaskToBack(true);
                    }
                });

                alertDialogBuilder.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();
            }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_keluar) {
           new LogLogout().execute();
        }
        else if (id == R.id.action_password)
        {
            Intent a = new Intent(MainActivity.this, GantiPassword.class);
            startActivity(a);
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();


        if (id == R.id.nav_about) {

            tampilAbout();

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    public void logout(){
        SharedPreferences sharedpreferences = sharePref;
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.clear();
        editor.commit();
        moveTaskToBack(true);
        Intent back = new Intent(MainActivity.this,Splash.class);
        MainActivity.this.finish();
        startActivity(back);

    }
    public void tampilAbout(){


        TextView title,subTitle,formTitle;
        ImageView imgPrompt;
        LayoutInflater li = LayoutInflater.from(MainActivity.this);
        View promptsView = li.inflate(R.layout.about, null);

        AlertDialog.Builder alert = new AlertDialog.Builder(MainActivity.this);
        alert.setView(promptsView);


        title = (TextView) promptsView.findViewById(R.id.txtTitlePrompt);
        subTitle = (TextView) promptsView.findViewById(R.id.txtSubTitlePrompt);
        imgPrompt = (ImageView)promptsView.findViewById(R.id.imgPrompt);
        formTitle = (TextView) promptsView.findViewById(R.id.txtFormTitle);

        title.setText("Created by :");
        formTitle.setText("ICON + v1.0");
        subTitle.setText("PT. Indonesia Comnets Plus");
       // Picasso.with(MainActivity.this).load(R.mipmap.logo).into(imgPrompt);
        alert.setPositiveButton("OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        dialog.cancel();

                    }
                });


        // create alert dialog
        //alert.setTitle("Zero Delay v1.0");
        AlertDialog alertDial = alert.create();

        // show it
        alertDial.show();



    }

    private class LogLogout extends AsyncTask<Void,Void,String> {


        private ProgressDialog pd = new ProgressDialog(MainActivity.this);
        protected void onPreExecute() {
            super.onPreExecute();
            pd.setCancelable(false);
            pd.setMessage("Loading...");
            pd.show();
        }

        @Override
        protected String doInBackground(Void... params) {


            ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
            nameValuePairs.add(new BasicNameValuePair("serpo",profNamaSerpo));
            nameValuePairs.add(new BasicNameValuePair("username",profUsername));


            new fungsi().sendData(URLKirimLog, nameValuePairs);
            return "Success";

        }
        @Override
        protected void onCancelled() {
            pd.hide();
            pd.dismiss();
            super.onCancelled();
        }

        protected void onPostExecute(String result) {

            pd.hide();
            pd.dismiss();

            logout();

        }
    }

}
