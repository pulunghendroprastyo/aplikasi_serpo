package com.example.pulung.iconplus.Perangkat;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.pulung.iconplus.R;

/**
 * Created by pulung on 11/28/17.
 */

public class CLVPerangkat extends ArrayAdapter<String> {
    //Declarasi
    private final Activity context;
    private final String[] vId;
    private final String[] vNama;


    public CLVPerangkat(Activity context, String[] Id, String[] Nama) {
        super(context, R.layout.list, Nama);
        this.context    = context;
        this.vId        = Id;
        this.vNama      = Nama;


    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        //Load Custom Layout untuk list
        View rowView = inflater.inflate(R.layout.list, null, true);
        //Declarasi komponen
        RelativeLayout reasonCard = (RelativeLayout) rowView.findViewById(R.id.listLayout);

        //Declarasi komponen
        TextView titleTxt = (TextView) rowView.findViewById(R.id.txtNama);
        titleTxt.setText(vNama[position]);


        return rowView;
    }
}

