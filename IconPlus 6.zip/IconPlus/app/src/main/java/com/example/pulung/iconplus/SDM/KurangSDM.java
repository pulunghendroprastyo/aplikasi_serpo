package com.example.pulung.iconplus.SDM;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.pulung.iconplus.MainActivity;
import com.example.pulung.iconplus.R;
import com.example.pulung.iconplus.fungsi;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class KurangSDM extends AppCompatActivity {

    String aksi,nama_sdm,profUsername,profNamaSerpo,profIdSerpo,gambar,nama;
    String keterangan,URLKirim;
    TextView TXTAksi,TXTSDM;
    EditText ETNama, ETKeterangan;
    SharedPreferences sharePref;
    Button btnInput;

    ArrayList<String> NamaSDMList;
    HashMap<Integer,String> spinnerMap;

    String URLSDM, id_ss,nama_orang,dataSDM;
    int id_ss1;
    Spinner SpinnerSDM;
    String GetNama,GetId;

    private static final String Json_data   ="aksi";
    private static final String Json_IdSS   ="id_ss",
                                Json_Nama   ="nama_orang";

    // Data Array JSONArray
    JSONArray DatafromJsonSDM = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kurang_sdm);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        //INTENT
        aksi      = getIntent().getStringExtra("aksi");
        nama_sdm  = getIntent().getStringExtra("nama_sdm");

        //DEKLARASI
        TXTAksi             = (TextView) findViewById(R.id.txtAksi);
        TXTSDM              = (TextView) findViewById(R.id.txtSDM);
        final CardView CVAR = (CardView) findViewById(R.id.cardAR);

        TXTAksi.setText(aksi);
        TXTSDM.setText(nama_sdm);

        ETKeterangan    = (EditText) findViewById(R.id.ETKeterangan);
        btnInput        = (Button) findViewById(R.id.btnInput);

        //SESSION
        sharePref       = getSharedPreferences("profShare", Context.MODE_PRIVATE);
        profUsername    = sharePref.getString("profUsername","");
        profNamaSerpo   = sharePref.getString("profNamaSerpo","");
        profIdSerpo     = sharePref.getString("profIdSerpo","");

        // Get Data Spinner json
        SpinnerSDM  =(Spinner)findViewById(R.id.SpinnerSDM);
        URLSDM      = getString(R.string.main_web)+"data_orang_sdm.php?id_serpo="+profIdSerpo+"&nama_sdm="+nama_sdm;
        URLSDM      = URLSDM.replace(" ","%20");
        new JSONSpinnerSDM().execute();

        // Toast.makeText(InputAksesoris.this,"ID:"+profIdSerpo,Toast.LENGTH_LONG).show();

        URLKirim = getString(R.string.main_web)+"input_sdm.php";

        btnInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                keterangan  = ETKeterangan.getText().toString();
                kirimData();

                // Toast.makeText(InputAksesoris.this,"Jumlah:"+jumlah+" No. Asr:"+no_asr+" Keterangan:"+keterangan+" Username:"+profUsername+" Serpo:"+profNamaSerpo+" Gambar:"+gambar+" milik:"+milik,Toast.LENGTH_LONG).show();

            }
        });

    }
    private class JSONSpinnerSDM extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... params) {
            // Creating service handler class instance
            NamaSDMList = new ArrayList<String>();
            dataSDM = new fungsi().getString(KurangSDM.this, URLSDM);

            Log.d("Response: ", "> " + dataSDM);
            if (dataSDM != null) {
                try {
                    JSONObject jsonObj = new JSONObject(dataSDM);

                    // Getting JSON Array node
                    DatafromJsonSDM = jsonObj.getJSONArray(Json_data);

                    spinnerMap = new HashMap<Integer, String>();

                    // looping through All Contacts
                    for (int i = 0; i < DatafromJsonSDM.length(); i++) {
                        JSONObject c = DatafromJsonSDM.getJSONObject(i);

                        // mengambil data json
                        id_ss       = c.getString(Json_IdSS);
                        //id_ss1      = Integer.parseInt(id_ss);
                        nama_orang  = c.getString(Json_Nama);
                        spinnerMap.put(i,id_ss);
                        NamaSDMList.add(nama_orang);

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                Log.e("ServiceHandler", "Couldn't get any data from the url");
            }

            return null;

        }


        @Override
        protected void onPostExecute(Void args) {
            // Locate the spinner in activity_main.xml

            ArrayAdapter<String> additionArray = new ArrayAdapter<String>(KurangSDM.this,
                    android.R.layout.simple_spinner_item,
                    NamaSDMList);
            additionArray.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            SpinnerSDM.setAdapter(additionArray);
            SpinnerSDM.setPrompt("Pilih");
            SpinnerSDM.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                    GetNama = SpinnerSDM.getSelectedItem().toString();
                    GetId = spinnerMap.get(SpinnerSDM.getSelectedItemPosition());
                    //Toast.makeText(KurangSDM.this, GetId, Toast.LENGTH_LONG).show();
                    //GetIdKecamatan = String.valueOf(position+1);


                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        }
    }

    public class uploadToServer extends AsyncTask<Void, Void, String> {


        private ProgressDialog pd = new ProgressDialog(KurangSDM.this);
        protected void onPreExecute() {
            super.onPreExecute();
            pd.setCancelable(false);
            pd.setMessage("Mengurangi Data SDM ...");
            pd.show();
        }

        @Override
        protected String doInBackground(Void... params) {


            ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(6);
            nameValuePairs.add(new BasicNameValuePair("id_serpo",profIdSerpo));
            nameValuePairs.add(new BasicNameValuePair("id_ss",GetId));
            nameValuePairs.add(new BasicNameValuePair("nama_sdm",nama_sdm));
            nameValuePairs.add(new BasicNameValuePair("nama_orang",GetNama));
            nameValuePairs.add(new BasicNameValuePair("ket_transaksi",aksi));
            nameValuePairs.add(new BasicNameValuePair("keterangan",keterangan));
            nameValuePairs.add(new BasicNameValuePair("username",profUsername));

            new fungsi().sendData(URLKirim, nameValuePairs);
            return "Success";

        }
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();
            Toast.makeText(getApplicationContext(), "Berhasil mengurangi SDM ", Toast.LENGTH_SHORT).show();

            Intent kembali = new Intent(getApplicationContext(),MainActivity.class);

            startActivity(kembali);
        }


    }
    private void kirimData() {

        if (GetNama.equals("")) {
            Toast.makeText(getApplicationContext(), "Nama belum diisi",
                    Toast.LENGTH_SHORT).show();
        } else if (ETKeterangan.getText().toString().equals("")) {
            Toast.makeText(getApplicationContext(), "Keterangan belum diisi",
                    Toast.LENGTH_SHORT).show();
        } else {

            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(KurangSDM.this);
            alertDialogBuilder.setMessage("Apakah semua data sudah benar ?");

            alertDialogBuilder.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface arg0, int arg1) {

                   new uploadToServer().execute();

                }
            });

            alertDialogBuilder.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });

            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();

        }

    }

}

