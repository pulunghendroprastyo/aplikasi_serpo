package com.example.pulung.iconplus.Fasilitas;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.pulung.iconplus.MainActivity;
import com.example.pulung.iconplus.R;
import com.example.pulung.iconplus.fungsi;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class KurangFasilitas extends AppCompatActivity {

    String aksi,profUsername,profNamaSerpo,profIdSerpo,merk,GetMerk="",GetIMEI="",imei;
    String keterangan,URLKirim,nama_fasilitas,id_fasilitas,id_fs;
    TextView TXTAksi,TXTNama;
    EditText ETKeterangan;
    SharedPreferences sharePref;
    Button btnInput;

    ArrayList<String> NamaMerkList;
    ArrayList<String> NamaIMEIList;
    HashMap<Integer,String> spinnerMap;

    String URLMerk,URLIMEI,dataMerk,dataIMEI;

    Spinner SpinnerMerk,SpinnerIMEI;
    String GetId;

    private static final String Json_data   ="aksi";
    private static final String Json_Merk   ="merk",
            Json_IdFs   ="id_fs",
            Json_Imei   ="imei";

    // Data Array JSONArray
    JSONArray DatafromJsonMerk = null;
    JSONArray DatafromJsonIMEI = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kurang_fasilitas);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        //INTENT
        aksi            = getIntent().getStringExtra("aksi");
        nama_fasilitas  = getIntent().getStringExtra("nama_fasilitas");
        id_fasilitas    = getIntent().getStringExtra("id_fasilitas");

        //DEKLARASI
        TXTAksi             = (TextView) findViewById(R.id.txtAksi);
        TXTNama             = (TextView) findViewById(R.id.txtNama);
        final CardView CVAR = (CardView) findViewById(R.id.cardAR);

        TXTAksi.setText(aksi);
        TXTNama.setText(nama_fasilitas);

        ETKeterangan    = (EditText) findViewById(R.id.ETKeterangan);
        btnInput        = (Button) findViewById(R.id.btnInput);

        //SESSION
        sharePref       = getSharedPreferences("profShare", Context.MODE_PRIVATE);
        profUsername    = sharePref.getString("profUsername","");
        profNamaSerpo   = sharePref.getString("profNamaSerpo","");
        profIdSerpo     = sharePref.getString("profIdSerpo","");

        // Get Data Spinner json
        SpinnerMerk  =(Spinner)findViewById(R.id.SpinnerMerk);
        SpinnerIMEI  =(Spinner)findViewById(R.id.SpinnerIMEI);
        URLMerk      = getString(R.string.main_web)+"cek_merk_fasilitas.php?id_serpo="+profIdSerpo+"&id_fasilitas="+id_fasilitas;
        URLMerk      = URLMerk.replace(" ","%20");
        new JSONSpinnerMerk().execute();

        // Toast.makeText(InputAksesoris.this,"ID:"+profIdSerpo,Toast.LENGTH_LONG).show();

        URLKirim = getString(R.string.main_web)+"input_fasilitas.php";

        btnInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                keterangan  = ETKeterangan.getText().toString();
                kirimData();

                // Toast.makeText(InputAksesoris.this,"Jumlah:"+jumlah+" No. Asr:"+no_asr+" Keterangan:"+keterangan+" Username:"+profUsername+" Serpo:"+profNamaSerpo+" Gambar:"+gambar+" milik:"+milik,Toast.LENGTH_LONG).show();

            }
        });

    }
    private class JSONSpinnerMerk extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... params) {
            // Creating service handler class instance
            NamaMerkList = new ArrayList<String>();
            dataMerk = new fungsi().getString(KurangFasilitas.this, URLMerk);

            Log.d("Response: ", "> " + dataMerk);
            if (dataMerk != null) {
                try {
                    JSONObject jsonObj = new JSONObject(dataMerk);

                    // Getting JSON Array node
                    DatafromJsonMerk = jsonObj.getJSONArray(Json_data);

                    // looping through All Contacts
                    for (int i = 0; i < DatafromJsonMerk.length(); i++) {
                        JSONObject c = DatafromJsonMerk.getJSONObject(i);

                        merk  = c.getString(Json_Merk);
                        NamaMerkList.add(merk);

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                Log.e("ServiceHandler", "Couldn't get any data from the url");
            }

            return null;

        }


        @Override
        protected void onPostExecute(Void args) {
            // Locate the spinner in activity_main.xml

            ArrayAdapter<String> additionArray = new ArrayAdapter<String>(KurangFasilitas.this,
                    android.R.layout.simple_spinner_item,
                    NamaMerkList);
            additionArray.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            SpinnerMerk.setAdapter(additionArray);
            SpinnerMerk.setPrompt("Pilih");
            SpinnerMerk.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                    GetMerk = SpinnerMerk.getSelectedItem().toString();

                    URLIMEI      = getString(R.string.main_web)+"cek_imei.php?id_serpo="+profIdSerpo+"&id_fasilitas="+id_fasilitas+"&merk="+GetMerk;
                    URLIMEI      = URLIMEI.replace(" ","%20");
                    new JSONSpinnerIMEI().execute();


                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        }
    }
    private class JSONSpinnerIMEI extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... params) {
            // Creating service handler class instance
            NamaIMEIList = new ArrayList<String>();
            dataIMEI = new fungsi().getString(KurangFasilitas.this, URLIMEI);

            Log.d("Response: ", "> " + dataIMEI);
            if (dataIMEI != null) {
                try {
                    JSONObject jsonObj = new JSONObject(dataIMEI);

                    // Getting JSON Array node
                    DatafromJsonIMEI = jsonObj.getJSONArray(Json_data);
                    spinnerMap = new HashMap<Integer, String>();

                    // looping through All Contacts
                    for (int i = 0; i < DatafromJsonIMEI.length(); i++) {
                        JSONObject c = DatafromJsonIMEI.getJSONObject(i);

                        id_fs   = c.getString(Json_IdFs);
                        imei    = c.getString(Json_Imei);
                        spinnerMap.put(i,id_fs);
                        NamaIMEIList.add(imei);

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                Log.e("ServiceHandler", "Couldn't get any data from the url");
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void args) {
            // Locate the spinner in activity_main.xml

            ArrayAdapter<String> additionArray = new ArrayAdapter<String>(KurangFasilitas.this,
                    android.R.layout.simple_spinner_item,
                    NamaIMEIList);
            additionArray.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            SpinnerIMEI.setAdapter(additionArray);
            SpinnerIMEI.setPrompt("Pilih");
            SpinnerIMEI.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                    GetIMEI = SpinnerIMEI.getSelectedItem().toString();
                    GetId = spinnerMap.get(SpinnerIMEI.getSelectedItemPosition());

                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        }
    }

    public class uploadToServer extends AsyncTask<Void, Void, String> {


        private ProgressDialog pd = new ProgressDialog(KurangFasilitas.this);
        protected void onPreExecute() {
            super.onPreExecute();
            pd.setCancelable(false);
            pd.setMessage("Mengurangi Data Fasilitas ...");
            pd.show();
        }

        @Override
        protected String doInBackground(Void... params) {


            ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(9);
            nameValuePairs.add(new BasicNameValuePair("id_serpo",profIdSerpo));
            nameValuePairs.add(new BasicNameValuePair("id_fs",GetId));
            nameValuePairs.add(new BasicNameValuePair("nama_serpo",profNamaSerpo));
            nameValuePairs.add(new BasicNameValuePair("id_fasilitas",id_fasilitas));
            nameValuePairs.add(new BasicNameValuePair("imei",GetIMEI));
            nameValuePairs.add(new BasicNameValuePair("keterangan",keterangan));
            nameValuePairs.add(new BasicNameValuePair("merk",GetMerk));
            nameValuePairs.add(new BasicNameValuePair("username",profUsername));
            nameValuePairs.add(new BasicNameValuePair("ket_transaksi",aksi));

            new fungsi().sendData(URLKirim, nameValuePairs);
            return "Success";

        }
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();
            Toast.makeText(getApplicationContext(), "Berhasil mengurangi fasilitas ", Toast.LENGTH_SHORT).show();

            Intent kembali = new Intent(getApplicationContext(),MainActivity.class);

            startActivity(kembali);
        }


    }
    private void kirimData() {

        if (GetMerk.equals("")) {
            Toast.makeText(getApplicationContext(), "Merk Kosong",
                    Toast.LENGTH_SHORT).show();
        }
        else if (GetIMEI.equals("")) {
            Toast.makeText(getApplicationContext(), "IMEI Kosong",
                    Toast.LENGTH_SHORT).show();
        }
        else if (ETKeterangan.getText().toString().equals("")) {
            Toast.makeText(getApplicationContext(), "Keterangan belum diisi",
                    Toast.LENGTH_SHORT).show();
        } else {

            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(KurangFasilitas.this);
            alertDialogBuilder.setMessage("Apakah semua data sudah benar ?");

            alertDialogBuilder.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface arg0, int arg1) {

                    new uploadToServer().execute();

                }
            });

            alertDialogBuilder.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });

            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();

        }

    }

}