package com.example.pulung.iconplus.Kabel;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.pulung.iconplus.DataKabel.CLVDataKabel;
import com.example.pulung.iconplus.DataKabel.DataKabel;
import com.example.pulung.iconplus.DetailKabel.DetailKabel;
import com.example.pulung.iconplus.R;
import com.example.pulung.iconplus.fungsi;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ListKabel extends AppCompatActivity {


    ListView listProses;
    String[][] rJson;
    String[] rIdKabel, rNamaKabel,rGambar, rJumlahKabel;
    ProgressBar waitList;
    String aksi;

    SharedPreferences sharePref;
    String URLlvm,profIdSerpo;

    TextView noData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_kabel);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        aksi = getIntent().getStringExtra("aksi");

        listProses = (ListView) findViewById(R.id.listViewProses);
        waitList =(ProgressBar)findViewById(R.id.progressBar1);

        noData = (TextView) findViewById(R.id.txtNoData) ;
        //SESSION
        sharePref       = getSharedPreferences("profShare", Context.MODE_PRIVATE);
        profIdSerpo   = sharePref.getString("profIdSerpo","");

        if (aksi.trim().equals("Tambah"))
        {
            URLlvm = getString(R.string.main_web)+"data_kabel.php";
            URLlvm = URLlvm.replace(" ","%20");
            new listViewProses().execute();

        }
        else {
            URLlvm = getString(R.string.main_web)+"list_data_kabel.php?id_serpo="+profIdSerpo;
            URLlvm = URLlvm.replace(" ","%20");
            new listViewKurang().execute();

        }



    }


    private class listViewProses extends AsyncTask<Void,Void,String> {



        String resultLVM;
        protected void onPreExecute() {
            super.onPreExecute();
            waitList.setVisibility(View.VISIBLE);
            noData.setVisibility(View.INVISIBLE);
        }

        @Override
        protected String doInBackground(Void... params) {

            resultLVM = new fungsi().getString(ListKabel.this, URLlvm);

            try {

                JSONObject jsObjek2 = new JSONObject(resultLVM);

                String dataAksi = jsObjek2.getString("aksi");

                if (dataAksi!=null){

                    JSONArray jArrayTanam = new JSONArray(dataAksi);

                    rJson = new String[jArrayTanam.length()][3];

                    for (int i = 0; i < jArrayTanam.length(); i++) {
                        JSONObject json_data5 = jArrayTanam.getJSONObject(i);


                        rJson[i][0] = json_data5.getString("id_kabel");
                        rJson[i][1] = json_data5.getString("nama_kabel");
                        rJson[i][2] = json_data5.getString("gambar");


                    }

                    rIdKabel    = new String[rJson.length];
                    rNamaKabel  = new String[rJson.length];
                    rGambar     = new String[rJson.length];



                    for (int x = 0; x < rJson.length; x++) {

                        rIdKabel[x] = rJson[x][0];
                        rNamaKabel[x] = rJson[x][1];
                        rGambar[x] = rJson[x][2];



                    }
                }
            } catch (JSONException e) {
                Log.e("log_tag", "Error parsing data " + e.toString());
                e.printStackTrace();
                cancel(true);
            }

            return null;
        }

        @Override
        protected void onCancelled(String s) {
            super.onCancelled(s);
            listProses.setAdapter(null);

            //Toast.makeText(HomeActivity.this.HomeActivity.this, "No Data", Toast.LENGTH_SHORT).show();
            waitList.setVisibility(View.INVISIBLE);
            noData.setVisibility(View.VISIBLE);

        }

        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            waitList.setVisibility(View.INVISIBLE);
            noData.setVisibility(View.INVISIBLE);
            //Toast.makeText(HomeActivity.this.HomeActivity.this, resultLVM, Toast.LENGTH_SHORT).show();

            final CLVKabel adapter = new CLVKabel(ListKabel.this,rNamaKabel,rIdKabel,rGambar);
            //get Id List

            //Set adapter to list
            listProses.setAdapter(adapter);
            //Set ketika salah satu list di pilih(klik)
            listProses.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                    Intent a = new Intent(ListKabel.this, InputKabel.class);
                    a.putExtra("nama_kabel",rNamaKabel[position]);
                    a.putExtra("id_kabel",rIdKabel[position]);
                    a.putExtra("aksi",aksi);
                    startActivity(a);

                    //Toast.makeText(ListAksesoris.this, "Anda Memilih "+rNamaAksesoris[position]+rIdAksesoris[position]+aksi, Toast.LENGTH_SHORT).show();


                }
            });

        }
    }

    private class listViewKurang extends AsyncTask<Void,Void,String> {



        String resultLVM;
        protected void onPreExecute() {
            super.onPreExecute();
            waitList.setVisibility(View.VISIBLE);
            noData.setVisibility(View.INVISIBLE);
        }

        @Override
        protected String doInBackground(Void... params) {

            resultLVM = new fungsi().getString(ListKabel.this, URLlvm);

            try {

                JSONObject jsObjek2 = new JSONObject(resultLVM);

                String dataAksi = jsObjek2.getString("aksi");

                if (dataAksi!=null){

                    JSONArray jArrayTanam = new JSONArray(dataAksi);

                    rJson = new String[jArrayTanam.length()][3];

                    for (int i = 0; i < jArrayTanam.length(); i++) {
                        JSONObject json_data5 = jArrayTanam.getJSONObject(i);

                        rJson[i][0] = json_data5.getString("id_kabel");
                        rJson[i][1] = json_data5.getString("nama_kabel");
                        rJson[i][2] = json_data5.getString("jumlah_total");


                    }
                    rIdKabel      = new String[rJson.length];
                    rNamaKabel    = new String[rJson.length];
                    rJumlahKabel  = new String[rJson.length];



                    for (int x = 0; x < rJson.length; x++) {

                        rIdKabel[x]     = rJson[x][0];
                        rNamaKabel[x]   = rJson[x][1];
                        rJumlahKabel[x] = rJson[x][2];



                    }
                }
            } catch (JSONException e) {
                Log.e("log_tag", "Error parsing data " + e.toString());
                e.printStackTrace();
                cancel(true);
            }

            return null;
        }

        @Override
        protected void onCancelled(String s) {
            super.onCancelled(s);
            listProses.setAdapter(null);

            //Toast.makeText(HomeActivity.this.HomeActivity.this, "No Data", Toast.LENGTH_SHORT).show();
            waitList.setVisibility(View.INVISIBLE);
            noData.setVisibility(View.VISIBLE);

        }

        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            waitList.setVisibility(View.INVISIBLE);
            noData.setVisibility(View.INVISIBLE);
            //Toast.makeText(HomeActivity.this.HomeActivity.this, resultLVM, Toast.LENGTH_SHORT).show();

            final CLVDataKabel adapter = new CLVDataKabel(ListKabel.this,rIdKabel,rNamaKabel,rJumlahKabel);
            //get Id List

            //Set adapter to list
            listProses.setAdapter(adapter);
            //Set ketika salah satu list di pilih(klik)
            listProses.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                    Intent a = new Intent(ListKabel.this, InputKabel.class);
                    a.putExtra("nama_kabel",rNamaKabel[position]);
                    a.putExtra("id_kabel",rIdKabel[position]);
                    a.putExtra("aksi",aksi);
                    startActivity(a);

                    //Toast.makeText(ListAksesoris.this, "Anda Memilih "+rNamaAksesoris[position]+rIdAksesoris[position]+aksi, Toast.LENGTH_SHORT).show();


                }
            });

        }
    }
}

