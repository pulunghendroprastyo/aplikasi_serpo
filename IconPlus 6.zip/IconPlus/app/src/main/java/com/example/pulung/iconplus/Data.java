package com.example.pulung.iconplus;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import com.example.pulung.iconplus.DataAksesoris.DataAksesoris;
import com.example.pulung.iconplus.DataFasilitas.DataFasilitas;
import com.example.pulung.iconplus.DataKabel.DataKabel;
import com.example.pulung.iconplus.DataPerangkat.DataPerangkat;
import com.example.pulung.iconplus.DataSDM.ListDataSDM;
import com.example.pulung.iconplus.DataSarpen.DataSarpen;
import com.example.pulung.iconplus.DataTools.DataTools;
import com.example.pulung.iconplus.TAksesoris.ListTransaksiAksesoris;
import com.example.pulung.iconplus.TFasilitas.ListTransaksiFasilitas;
import com.example.pulung.iconplus.TKabel.ListTransaksiKabel;
import com.example.pulung.iconplus.TPerangkat.ListTransaksiPerangkat;
import com.example.pulung.iconplus.TSarpen.ListTransaksiSarpen;
import com.example.pulung.iconplus.TTools.ListTransaksiTools;

public class Data extends AppCompatActivity {

    String[] SData      = {"Data Aksesoris", "Data Kabel","Data Perangkat","Data SDM","Data Tools","Data Sarpen","Data Fasilitas"};
    String[] STransaksi = {"Transaksi Aksesoris", "Transaksi Kabel","Transaksi Perangkat","Transaksi Tools","Transaksi Sarpen","Transaksi Fasilitas"};
    TextView TXTJudul,TXTJudul2;
    String data,hasil,aksi;
    Button BTNNext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        //INTENT
        aksi        = getIntent().getStringExtra("aksi");

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(aksi);
        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        TXTJudul    = (TextView) findViewById(R.id.txtJudul);
        TXTJudul2    = (TextView) findViewById(R.id.txtJudul2);

        //SPINNER
        Spinner Data = (Spinner) findViewById(R.id.SpinnerData);

        if (aksi.equals("Data"))
        {

            TXTJudul.setText("Pilih Jenis Data di Bawah Ini:");
            TXTJudul2.setText("Data");

            ArrayAdapter<String> additionArray = new ArrayAdapter<String>(Data.this,
                    android.R.layout.simple_spinner_item,
                    SData);
            additionArray.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            Data.setAdapter(additionArray);
            Data.setPrompt("Pilih");
            Data.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    hasil = SData[position];
                    //Toast.makeText(MainActivity.this, menu,Toast.LENGTH_LONG).show();

                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {

                }

            });

        }
        else{

            TXTJudul.setText("Pilih Jenis Transaksi di Bawah Ini:");
            TXTJudul2.setText("Transaksi");

            ArrayAdapter<String> additionArray = new ArrayAdapter<String>(Data.this,
                    android.R.layout.simple_spinner_item,
                    STransaksi);
            additionArray.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            Data.setAdapter(additionArray);
            Data.setPrompt("Pilih");
            Data.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    hasil = STransaksi[position];
                    //Toast.makeText(MainActivity.this, menu,Toast.LENGTH_LONG).show();

                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {

                }

            });

        }


        BTNNext     = (Button)   findViewById(R.id.btnNext);

        BTNNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                if (hasil.equals("Data Aksesoris"))
                {
                    Intent a = new Intent(getApplicationContext(), DataAksesoris.class);
                    startActivity(a);
                }

                else if (hasil.equals("Data Kabel"))
                {
                    Intent a = new Intent(getApplicationContext(), DataKabel.class);
                    startActivity(a);
                }
                else if (hasil.equals("Data Perangkat"))
                {
                    Intent a = new Intent(getApplicationContext(), DataPerangkat.class);
                    startActivity(a);
                }
                else if (hasil.equals("Data SDM"))
                {
                    Intent a = new Intent(getApplicationContext(), ListDataSDM.class);
                    startActivity(a);
                }
                else if (hasil.equals("Data Tools"))
                {
                    Intent a = new Intent(getApplicationContext(), DataTools.class);
                    startActivity(a);
                }
                else if (hasil.equals("Data Sarpen"))
                {
                    Intent a = new Intent(getApplicationContext(), DataSarpen.class);
                    startActivity(a);
                }
                else if (hasil.equals("Data Fasilitas"))
                {
                    Intent a = new Intent(getApplicationContext(), DataFasilitas.class);
                    startActivity(a);
                }

                else if (hasil.equals("Transaksi Aksesoris"))
                {
                    Intent a = new Intent(getApplicationContext(), ListTransaksiAksesoris.class);
                    startActivity(a);
                }

                else if (hasil.equals("Transaksi Kabel"))
                {
                    Intent a = new Intent(getApplicationContext(), ListTransaksiKabel.class);
                    startActivity(a);
                }
                else if (hasil.equals("Transaksi Perangkat"))
                {
                    Intent a = new Intent(getApplicationContext(), ListTransaksiPerangkat.class);
                    startActivity(a);
                }

                else if (hasil.equals("Transaksi Tools"))
                {
                    Intent a = new Intent(getApplicationContext(), ListTransaksiTools.class);
                    startActivity(a);
                }
                else if (hasil.equals("Transaksi Sarpen"))
                {
                    Intent a = new Intent(getApplicationContext(), ListTransaksiSarpen.class);
                    startActivity(a);
                }
                else if (hasil.equals("Transaksi Fasilitas"))
                {
                    Intent a = new Intent(getApplicationContext(), ListTransaksiFasilitas.class);
                    startActivity(a);
                }





            }
        });

    }
}
